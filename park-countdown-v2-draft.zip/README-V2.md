# Park Day Countdown — experimental V2

This is an additive preview, not a replacement for the original PWA. Keep the original root index.html, original manifest, service worker, images and other source files intact. Copy only the `preview/` directory into a new `development/v2` branch. GitHub Pages must be separately configured if you want a public preview; do not switch the production Pages source to this branch.

## Local preview

From the repository root, run `python3 -m http.server 8000`, then visit `http://localhost:8000/preview/`. Use a static HTTPS host for installation on iOS. For same-origin imports, open the original PWA and preview under the same origin and browser profile; data stored on the live GitHub Pages site will not appear automatically on localhost or a separate preview domain. The original keys are read only. V2 writes `parkCountdown.v2.preview`; its service worker is scoped to `preview/` and only cleans its own caches.

## Working prototype scope

- Trip creation and editing, existing trip import, countdown and automatic date-based modes, resort selection, 22 resort/other entries and themed gradients.
- Personal resort image upload (one small licensed photo per resort), itinerary, checklist, milestone list, budget, manual expense and ride logs, achievements, journal, shareable text recap and backup export.
- Live ThemeParks.wiki attraction data (configured park IDs read from original), recent local wait history, in-app thresholds and browser notifications where supported while open. No fabricated live values. Real notification delivery on iOS, background refresh, ride reopening alerts and data-provider integration require additional work.
- Walking totals read the original data when on the same origin; original park maps and picture packs are unchanged and accessible via the original app link. Not imported into the V2 interface.

## Deliberate limitations

No licensed resort artwork bundled. Resort catalog/transportation needs verification prior to publishing; no full resort amenity database, weather, showtimes, restaurant lists, zip picture-pack integration, ride completion denominator, resort passport, automatic reminders, family sync, native iOS integration, offline live waits, backup restore or full background monitoring. Native features (HealthKit, ActivityKit, WidgetKit, Apple Watch, iCloud) are roadmap only. V2 is not a production-ready replacement. Browser notification support varies; mobile Safari may reject the Notification constructor. No end-to-end iOS/browser tests or live API verification performed here. Countdown dates use the device local timezone for newly created trips, and a best-effort timezone conversion for original imported trips. Review app store, artwork and API licensing before public launch.
